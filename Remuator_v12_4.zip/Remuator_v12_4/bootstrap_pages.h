#pragma once
// Создано tools/build_bootstrap.py. Файлы LittleFS и ресурсы интернета не требуются.
static const char BOOTSTRAP_WIFI_HTML[] PROGMEM = R"BOOTPAGE(<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Первое подключение — Remuage-VRN</title><style>body{font:17px system-ui;background:#edf3ef;color:#183b2e;margin:0;padding:20px}main{max-width:650px;margin:24px auto;background:white;padding:26px;border-radius:16px}label{display:block;margin:16px 0}input,button,a.button{box-sizing:border-box;font:inherit;padding:12px;border-radius:8px;border:1px solid #a7bbae}input{display:block;width:100%;margin-top:6px}button,a.button{display:inline-block;background:#23624a;color:white;cursor:pointer;text-decoration:none}button:disabled{opacity:.5}p{line-height:1.5}.error{color:#a52c24}code{overflow-wrap:anywhere}ul{max-height:200px;overflow:auto}[hidden]{display:none!important}</style></head><body><main><h1>Первое подключение</h1><p>Веб-файлы контроллера ещё не загружены. Эта страница встроена в прошивку и работает без LittleFS.</p><p id="state" role="status">Проверка сети…</p><p id="error" role="alert" class="error" hidden></p><form id="wifiForm" action="/setup/wifi" method="post"><label>Название сети Wi-Fi (SSID)<input name="ssid" maxlength="32" autocomplete="off" required></label><label>Пароль Wi-Fi<input name="pass" type="password" maxlength="64" autocomplete="new-password"><small>Оставьте пустым для открытой сети.</small></label><input type="hidden" name="homeen" value="1"><button id="connect">Сохранить и подключиться</button></form><p id="address"></p><a id="manager" class="button" hidden>Открыть встроенный файловый менеджер</a><p>Точка доступа контроллера остаётся включённой. При заводских настройках: сеть <strong>RemuageVRN</strong>, пароль <strong>43214321</strong>, адрес <code>http://192.168.4.1/</code>.</p><p>После подключения контроллера к Wi-Fi откроется встроенный файловый менеджер. Для него используются прежние логин и пароль.</p><details><summary>Какие файлы отсутствуют</summary><ul id="missing"></ul></details></main><script>
(() => {
  const $=id=>document.getElementById(id);
  let redirected=false,submittedAt=0;
  const managerUrl=(host=location.hostname)=>{const u=new URL(location.href);u.hostname=host;u.port='8080';u.pathname='/bootstrap';u.search='';u.hash='';return u.href;};
  async function poll(){
    try{
      const r=await fetch('/setup/status',{cache:'no-store'});if(!r.ok)throw Error(await r.text());const d=await r.json();
      $('missing').replaceChildren(...d.missing.map(name=>{const li=document.createElement('li');li.textContent=name;return li;}));
      $('manager').href=managerUrl();$('manager').hidden=false;
      if(d.webReady){location.replace('/');return;}
      $('state').textContent=!d.fsMounted?'LittleFS не смонтирована. Проверьте таблицу разделов и состояние памяти; существующие данные не стирались.':d.staConnected?'Контроллер подключён к Wi-Fi. Переход к файловому менеджеру…':submittedAt&&Date.now()-submittedAt>30000?'Подключение пока не удалось: проверьте SSID и пароль, диапазон 2,4 ГГц и доступность сети.':'Задайте Wi-Fi 2,4 ГГц. Точка доступа контроллера продолжает работать.';
      if(d.staConnected){
        const a=document.createElement('a');a.href=managerUrl(d.sta);a.textContent='Адрес менеджера в домашней сети: '+a.href;$('address').replaceChildren(a);
        if(!redirected){redirected=true;location.assign(managerUrl());}
      }
    }catch(e){$('error').textContent=String(e.message||e)+' Как исправить: проверьте питание и подключение к Wi-Fi контроллера, затем обновите страницу.';$('error').hidden=false;}
  }
  $('wifiForm').addEventListener('submit',async e=>{
    e.preventDefault();$('connect').disabled=true;$('error').hidden=true;
    try{const r=await fetch('/setup/wifi',{method:'POST',cache:'no-store',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8','X-Requested-With':'XMLHttpRequest'},body:new URLSearchParams(new FormData(e.target))});if(!r.ok)throw Error(await r.text());$('wifiForm').elements.pass.value='';submittedAt=Date.now();$('state').textContent='Настройки сохранены. Ожидается подключение к сети…';await poll();}
    catch(e){$('error').textContent=String(e.message||e)+' Проверьте название сети и пароль и повторите подключение.';$('error').hidden=false;}
    finally{$('connect').disabled=false;}
  });
  poll();setInterval(poll,2500);
})();
</script></body></html>
)BOOTPAGE";
static const char BOOTSTRAP_MANAGER_HTML[] PROGMEM = R"BOOTPAGE(<!doctype html>
<html lang="ru">
  <head>
    <meta charset="utf-8" />
    
    
    <meta content="width=device-width,initial-scale=1" name="viewport" />
    <title>Remuage-VRN — файлы LittleFS</title>
    <style>:root {
  color-scheme: light;
  --ink: #192d32;
  --muted: #5e7379;
  --green: #22684e;
  --line: #d8e2e3;
}
* {
  box-sizing: border-box;
}
body {
  margin: 0;
  font:
    15px/1.5 system-ui,
    -apple-system,
    sans-serif;
  color: var(--ink);
  background: #f2f5f3;
}
header {
  display: flex;
  justify-content: space-between;
  gap: 24px;
  align-items: center;
  padding: 20px max(24px, calc((100vw - 1400px) / 2));
  background: #163e34;
  color: white;
}
header strong {
  font-size: 20px;
  letter-spacing: 0.04em;
}
header small {
  display: block;
  color: #c0d6cc;
}
header nav {
  display: flex;
  gap: 20px;
  flex-wrap: wrap;
}
header a {
  color: white;
  text-decoration: none;
}
main {
  max-width: 1448px;
  margin: auto;
  padding: 24px;
}
h1 {
  font-size: 28px;
  margin: 0 0 20px;
}
h2 {
  font-size: 19px;
  margin: 0 0 12px;
}
a {
  color: var(--green);
}
.card {
  padding: 22px;
  border: 1px solid var(--line);
  border-radius: 12px;
  background: white;
  margin-bottom: 18px;
  min-width: 0;
}
.grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 340px), 1fr));
  gap: 18px;
}
.grid .card {
  margin-bottom: 0;
}
.toolbar,
.spread {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}
.spread {
  justify-content: space-between;
}
button,
.button {
  display: inline-block;
  font: inherit;
  color: var(--ink);
  text-decoration: none;
  padding: 9px 14px;
  border: 1px solid #b7c9c1;
  border-radius: 7px;
  background: white;
  cursor: pointer;
}
button:hover,
.button:hover {
  background: #eaf2ed;
}
.primary {
  background: var(--green);
  border-color: var(--green);
  color: white;
}
.primary:hover {
  background: #174e3a;
}
.danger {
  color: #a12834;
}
button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
input,
select {
  font: inherit;
  padding: 8px 10px;
  border: 1px solid #bfcecc;
  border-radius: 6px;
  background: white;
  color: inherit;
  width: 100%;
}
input[type="checkbox"] {
  width: auto;
}
.fields {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 240px), 1fr));
  gap: 18px;
  margin: 18px 0;
}
.fields label {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
fieldset {
  padding: 0;
  border: 0;
  margin: 0;
  min-width: 0;
}
.checks {
  display: grid;
  gap: 10px;
  margin: 18px 0;
}
.muted,
footer {
  color: var(--muted);
  font-size: 13px;
}
footer {
  margin-top: 28px;
}
code {
  overflow-wrap: anywhere;
}
.badge {
  background: #e9f3ec;
  border-radius: 20px;
  padding: 4px 12px;
}
#error {
  background: #fff1f1;
  border: 1px solid #e6b5ba;
  border-radius: 8px;
  padding: 14px;
  color: #a12834;
  margin-bottom: 18px;
}
#executionMessage {
  color: #82571c;
}
.scroll {
  max-height: 60vh;
  overflow: auto;
  margin-top: 18px;
}
table {
  width: 100%;
  border-collapse: collapse;
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
th,
td {
  padding: 10px;
  text-align: left;
  border-bottom: 1px solid var(--line);
}
th {
  background: #f5f8f6;
  position: sticky;
  top: 0;
  font-size: 12px;
}
tr.current {
  background: #e1f0e4;
  font-weight: 600;
}
tr.done {
  color: var(--muted);
}
.manual {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}
.manual button {
  touch-action: none;
  user-select: none;
  -webkit-user-select: none;
}
[hidden] {
  display: none !important;
}
@media (max-width: 650px) {
  header {
    padding: 16px;
    flex-direction: column;
    align-items: flex-start;
    gap: 12px;
  }
  header small {
    display: none;
  }
  main {
    padding: 14px;
  }
  .card {
    padding: 16px;
  }
}

/* Видимые границы столбцов в таблицах исполнения и настроек. */
th + th,
td + td {
  border-left: 1px solid #afc2b9;
}
.schedule-table {
  border: 1px solid #afc2b9;
}
.completion-check {
  width: 19px !important;
  height: 19px;
  accent-color: #257653;
  opacity: 1;
  vertical-align: middle;
}
.clock-panel {
  margin-top: 22px;
  padding: 15px 18px;
  background: #f1f7f3;
  border: 1px solid #d4e2d9;
  border-radius: 9px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.label {
  color: var(--muted);
  font-size: 12px;
}
.clock-panel strong {
  font-size: 21px;
  font-variant-numeric: tabular-nums;
}
.run-timeline {
  margin: 12px 0 22px;
  border: 1px solid var(--line);
  border-radius: 9px;
  overflow: hidden;
}
.run-timeline > div {
  display: grid;
  grid-template-columns: 230px 1fr;
  gap: 4px 18px;
  padding: 13px 18px;
}
.run-timeline > div + div {
  border-top: 1px solid var(--line);
}
.run-timeline dt {
  color: var(--muted);
}
.run-timeline dd {
  margin: 0;
  font-variant-numeric: tabular-nums;
}
#upcomingAction,
#currentChecks,
#currentPhase {
  grid-column: 2;
}
.pose-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
  margin-bottom: 16px;
}
.pose-grid figure {
  margin: 0;
  border: 1px solid var(--line);
  border-radius: 9px;
  padding: 16px;
  background: #fbfdfb;
}
.pose-grid figcaption {
  display: flex;
  justify-content: space-between;
  gap: 12px;
}
.pose-grid figcaption strong {
  color: var(--green);
  white-space: nowrap;
}
.pose-grid svg {
  display: block;
  width: 100%;
  height: 200px;
}
.axis-label {
  fill: #6b8074;
  font:
    12px system-ui,
    sans-serif;
}
.pose-note {
  grid-column: 1/-1;
  margin: 0;
}
.pose-grid.uncertain svg {
  opacity: 0.5;
}
@media (max-width: 650px) {
  .run-timeline > div {
    grid-template-columns: 1fr;
    gap: 5px;
  }
  #upcomingAction,
  #currentChecks,
  #currentPhase {
    grid-column: 1;
  }
  .clock-panel strong {
    font-size: 18px;
  }
  .pose-grid {
    grid-template-columns: 1fr;
  }
}

.notice,
.warning {
  padding: 12px 16px;
  border: 1px solid #b9c9bf;
  border-radius: 8px;
  background: #f0f6f2;
}
.warning {
  border-color: #bc8c3b;
  background: #fff6df;
  color: #694400;
}
.operation-checks {
  display: flex;
  flex-wrap: wrap;
  gap: 10px 24px;
}
.operation-checks label {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}
.completion-check:disabled {
  opacity: 1;
  accent-color: #23624a;
}

/* Общая навигация всех страниц. */
.site-header {
 position:sticky; top:0; z-index:150; width:100%;
 display:flex; justify-content:space-between; align-items:center; gap:16px;
 min-height:64px; padding:10px max(24px, calc((100vw - 1400px)/2));
 background:#163e34; color:#fff; box-shadow:0 2px 8px #0002;
}
.site-header .site-brand {color:#fff; font-weight:800; font-size:20px; letter-spacing:.035em; text-decoration:none; white-space:nowrap;}
.site-header .site-menu {display:flex; flex-wrap:wrap; align-items:center; justify-content:flex-end; gap:8px 18px;}
.site-header .site-menu a{color:#fff;text-decoration:none;white-space:nowrap;}
.site-header .site-menu a[aria-current="page"]{text-decoration:underline;text-underline-offset:5px;}
.site-footer {padding:16px max(24px,calc((100vw - 1400px)/2)); border-top:1px solid var(--line);
 margin:20px 0 0; display:flex; flex-wrap:wrap; align-items:center; gap:8px 16px;
 justify-content:space-between; background:#eaf0ec; font-size:13px; color:var(--muted);}
.site-footer strong {color:var(--ink);}
.settings-tabs {display:flex; flex-wrap:wrap; gap:8px; margin:2px 0 20px;}
.settings-tabs a {padding:7px 12px; border:1px solid #c7d8cf; border-radius:7px; text-decoration:none; background:#fff;}
.settings-tabs a[aria-current="page"] {color:#fff; background:#22684e;}
.check-inline{display:flex!important;flex-direction:row!important;align-items:center;gap:9px;}
.readme{white-space:pre-wrap;overflow-wrap:anywhere;background:#f6f8f7;border:1px solid var(--line);padding:18px;border-radius:9px;max-height:70vh;overflow:auto;}
.axis-values {display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin:14px 0;}
.axis-choices {border:1px solid var(--line);border-radius:7px;padding:12px;}
.axis-choices label{display:inline-flex;margin:8px 12px 0 0;align-items:center;flex-direction:row;gap:6px;}
.table-scroll {max-height:60vh;overflow:auto;}
@media(max-width:750px){
 .site-header {flex-direction:column; gap:7px; padding:7px 12px 9px; align-items:stretch;}
 .site-header .site-menu {order:-1;justify-content:center;gap:4px 14px;}
 .site-header .site-menu a {font-size:13px;padding:4px 0;}
 .site-header .site-brand {font-size:19px;text-align:center;}
 .site-footer{padding:12px 16px;}
}

/* Встроенный редактор CSV и сведения о выбранной программе в режиме ожидания. */
.program-summary {display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin:12px 0}
.program-summary>div {padding:12px;border:1px solid var(--border,#d5e0da);border-radius:10px}
.program-summary dt {font-size:.85rem;opacity:.75}
.program-summary dd {font-weight:650;margin:4px 0 0;font-variant-numeric:tabular-nums}
.start-at-panel {display:flex;flex-wrap:wrap;align-items:center;gap:10px;margin:12px 0 18px}
.start-at-panel input {width:6em;padding:8px}
.start-at-panel small {flex-basis:100%;opacity:.75}
.inline-editor iframe {width:100%;height:780px;border:0;border-radius:10px;background:white}
.schedule-table .skipped {opacity:.6}
.z-steps {font-weight:700;font-size:clamp(2rem,6vw,3.8rem);font-variant-numeric:tabular-nums}
.z-jog button {min-width:130px;touch-action:none;user-select:none}
@media(max-width:650px){.inline-editor iframe{height:760px}.z-jog button{min-height:62px}}

.selected-program {border:2px solid #23624a;background:#e6f2e9;}
label.inactive {color:#888;opacity:.65;}
input:disabled, select:disabled {background:#e3e3e3;color:#777;cursor:not-allowed;}
.parameter-help {border-radius:50%;padding:0 .35em;margin:0 .3em;font-size:.8rem;cursor:help;}
dialog {max-width:min(36rem,90vw);border:1px solid #aaa;border-radius:12px;}
dialog::backdrop {background:#0006;}

.schedule-table tbody td:nth-child(2), .schedule-table tbody td:nth-child(4),
.schedule-table tbody td:nth-child(7), .schedule-table tbody td:nth-child(8) { background: #e3ebe6; }
</style>
    <style>:root {
  color-scheme: dark;
}

* {
  box-sizing: border-box;
}

body {
  font:
    15px/1.5 system-ui,
    -apple-system,
    "Segoe UI",
    sans-serif;
  max-width: 1050px;
  margin: 24px auto;
  padding: 0 14px;
  background: #161c25;
  color: #edf3ff;
}

a {
  color: #80baff;
}

header {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}

h1 {
  font-size: 25px;
  margin: 0;
}

h2 {
  font-size: 18px;
  margin: 6px 0 12px;
}

.card {
  background: #232d3c;
  border: 1px solid #405069;
  border-radius: 10px;
  margin: 14px 0;
  padding: 16px;
}

button,
input,
textarea {
  font: inherit;
}

button,
.btn {
  display: inline-block;
  background: #3a79bb;
  color: white;
  border: 0;
  border-radius: 6px;
  cursor: pointer;
  padding: 8px 12px;
  text-decoration: none;
}

button:disabled {
  opacity: 0.5;
}

button.danger {
  background: #9a3b45;
}

button.small {
  padding: 4px 9px;
  font-size: 13px;
}

input {
  background: #101923;
  border: 1px solid #596b83;
  border-radius: 5px;
  padding: 8px;
  color: white;
  min-width: 0;
}

input[type="file"] {
  width: 100%;
}

textarea {
  background: #111923;
  border: 1px solid #596b83;
  color: #fff;
  width: 100%;
  min-height: 300px;
  border-radius: 6px;
  padding: 12px;
  font-family: monospace;
  font-size: 13px;
}

table {
  border-collapse: collapse;
  width: 100%;
}

th,
td {
  text-align: left;
  padding: 8px;
  border-bottom: 1px solid #485368;
  overflow-wrap: anywhere;
}

td.actions {
  white-space: nowrap;
}

tr:hover {
  background: #2a374a;
}

.muted {
  color: #bbc8da;
  font-size: 13px;
}

.flex {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.grow {
  flex: 1;
}

#message {
  min-height: 24px;
}

#message.error {
  color: #ffb9bd;
}

#drop {
  border: 2px dashed #6c8eb5;
  border-radius: 8px;
  text-align: center;
  padding: 16px;
  cursor: pointer;
}

#drop.drag {
  background: #344d65;
}

#editor {
  display: none;
}

@media (max-width: 720px) {
  body {
    margin: 8px auto;
  }
  td.actions {
    white-space: normal;
  }
  .actions button {
    margin: 2px;
  }
  th:nth-child(3),
  td:nth-child(3) {
    display: none;
  }
}

#uploadControls {
  margin-top: 10px;
}

/* Общая навигация ведёт себя так же, как на главном сайте. */
body{max-width:none;margin:0;padding:0;background:#161c25;}
.file-main{max-width:1100px;margin:auto;padding:22px 16px;}
.site-header{position:sticky;top:0;z-index:150;margin:0;width:100%;background:#163e34;}
.site-header .site-brand{color:#fff;}
.site-header .site-menu a{color:#fff;}
.site-footer{color:#213d32;}
.site-footer a{color:#22684e;}
.site-footer strong{color:#192d32;}
.file-main h1{margin-bottom:16px;}
</style>
      
  </head>
  <body>
    <header id="siteHeader"></header>
    <main class="file-main"><a id="back" class="btn" href="/" hidden>Назад</a>
<h1>Встроенный файловый менеджер LittleFS</h1><section class="card"><p>Эта страница находится в памяти прошивки и работает даже без веб-файлов. Загрузите содержимое data в корень /, а CSV — в /prog. ZIP предварительно распакуйте на компьютере.</p><button id="bootstrapCheck" type="button">Проверить веб-файлы</button><p id="bootstrapState" role="status"></p><a id="bootstrapMain" class="btn" hidden>Перейти на главную</a></section>
    <nav class="flex">
      <a class="btn" href="/?dir=/">Корень</a
      ><a class="btn" href="/?dir=/prog">Программы</a
      ><a class="btn" href="/?dir=/Logs">Логи</a>
    </nav>
    <p class="muted">
      Для проверки изменений открывайте главную страницу заново. HTML, CSS и JS
      загружаются из LittleFS; правки файла на компьютере требуют загрузки его
      на ESP32.
    </p>
    <p class="muted">
      Файловый менеджер работает на порту 8080. Обычная версия интерфейса хранится в LittleFS; текущая встроенная версия
      работает независимо от этих файлов. Для входа требуется HTTP Basic Authentication.
    </p>
    <div class="card">
      <div class="flex">
        <button id="button-up">↖ Выше</button>
        <strong class="grow" id="folder"> / </strong>
        <button id="button-refresh">Обновить</button>
      </div>
      <p id="message" role="status"></p>
      <table>
        <thead>
          <tr>
            <th>Имя</th>
            <th>Размер</th>
            <th>Тип</th>
            <th>Операции</th>
          </tr>
        </thead>
        <tbody id="entries">
          <tr>
            <td colspan="4">Загрузка…</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="card">
      <h2>Загрузка файлов</h2>
      <div id="drop">Перетащите сюда файлы или выберите их ниже</div>
      <div class="flex" id="uploadControls">
        <input class="grow" id="files" multiple="" type="file" />
        <button id="button-upload">Загрузить в эту папку</button>
      </div>
      <p class="muted">
        Все HTML, CSS, JS и favicon.ico из папки data загрузите в корень
        <code>/</code>. CSV храните в <code>/prog/</code>.
      </p>
    </div>
    <div class="card">
      <h2>Создать папку</h2>
      <div class="flex">
        <input class="grow" id="newfolder" placeholder="Например: prog" />
        <button id="button-mkdir">Создать</button>
      </div>
    </div>
    <div class="card" id="editor">
      <h2>
        Редактор
        <span id="editname"> </span>
      </h2>
      <textarea id="edittext" spellcheck="false"></textarea>
      <div class="flex">
        <button id="button-saveText">Сохранить</button>
        <button id="button-closeEditor">Закрыть</button>
      </div>
    </div>
    </main>
    <footer id="siteFooter"></footer>
    <script>// Все страницы используют общую навигацию, подвал и API версии прошивки.
(() => {
  const filePort = location.port === '8080';
  const base = new URL(location.href);
  base.port = location.protocol === 'https:' ? '' : '80';
  base.pathname = '/'; base.search = ''; base.hash = '';
  const href = (path) => filePort ? new URL(path, base).href : path;
  const manager = new URL(base);
  manager.port='8080';
  const nav = [
    ['/', 'Главная'], ['/programs', 'Программы'],
    ['/settings', 'Настройки'], ['/network', 'Сеть']
  ];
  const header=document.getElementById('siteHeader');
  if (header) {
    header.className='site-header';
    const title=document.createElement('a');
    title.className='site-brand'; title.href=href('/');
    title.textContent='Remuage-VRN';
    const links=document.createElement('nav'); links.className='site-menu';
    links.setAttribute('aria-label','Главное меню');
    const path=location.pathname;
    for (const [url,name] of nav) {
      const a=document.createElement('a'); a.href=href(url); a.textContent=name;
      if(!filePort && (path===url || (url==='/settings' && path.startsWith('/settings/')))) a.setAttribute('aria-current','page');
      links.appendChild(a);
    }
    header.replaceChildren(title,links);
  }
  const footer=document.getElementById('siteFooter');
  if(footer){
    footer.className='site-footer';
    const left=document.createElement('span');
    left.textContent='Remuage-VRN · '; 
    const docs=document.createElement('a');docs.href=href('/settings/about');docs.textContent='О программе';
    left.appendChild(docs);
    const f=document.createElement('a');f.href=manager.href;f.textContent='Файловый менеджер';
    const right=document.createElement('span');right.textContent='Прошивка: ';
    const ver=document.createElement('strong');ver.id='siteFooterVersion';ver.textContent='…';right.appendChild(ver);
    footer.replaceChildren(left,document.createTextNode(' · '),f,right);
  }
  const versionUrl='/api/version';
  fetch(versionUrl,{cache:'no-store'}).then(r=>{if(!r.ok) throw new Error('version');return r.json()})
    .then(x=>{const el=document.getElementById('siteFooterVersion');if(el)el.textContent=x.version?'v'+x.version:'недоступна'})
    .catch(()=>{const el=document.getElementById('siteFooterVersion');if(el)el.textContent='недоступна';});
})();
</script><script>let cwd = "/",
  active = "";
const $ = (id) => document.getElementById(id);
$("back").href =
  `${location.protocol}//${location.hostname}/?reload=${Date.now()}`;
function msg(t, bad = false) {
  $("message").textContent = bad ? t + " Как исправить: " + (/fetch|network|Load failed/i.test(String(t))
    ? "Проверьте питание, подключение к Wi-Fi контроллера и его IP; файловый менеджер работает на порту 8080. Повторите запрос."
    : "Проверьте путь, имя файла и свободное место; остановите двигатели перед изменением файлов и повторите действие.") : t;
  $("message").className = bad ? "error" : "";
}
function esc(s) {
  return String(s).replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
}
function validName(s) {
  return s && !s.includes("/") && !s.includes("\\") && s !== "." && s !== "..";
}
function join(dir, name) {
  return (dir === "/" ? "" : dir) + "/" + name;
}
async function fetchApi(url, opts) {
  let r = await fetch(url, { cache: "no-store", ...opts });
  if (!r.ok) {
    let t = await r.text();
    throw Error(t || "HTTP " + r.status);
  }
  return r;
}
async function refresh() {
  try {
    let r = await fetchApi("/api/list?dir=" + encodeURIComponent(cwd));
    let j = await r.json();
    const url = new URL(location.href);
    url.search = "?dir=" + encodeURIComponent(cwd);
    history.replaceState(null, "", url);
    $("folder").textContent =
      cwd + " (" + j.used + "/" + j.total + " байт занято)";
    const rows = j.entries
      .map(
        (f, i) =>
          `<tr><td>${f.directory ? "📁 " : "📄 "}<a href="#" data-open="${i}">${esc(f.name)}</a></td><td>${f.directory ? "—" : f.size}</td><td>${f.directory ? "Папка" : "Файл"}</td><td class="actions">${f.directory ? "" : `<button class="small" data-edit="${i}">Текст</button> <button class="small" data-download="${i}">↓</button>`} <button class="small" data-rename="${i}">Имя</button> <button class="small danger" data-delete="${i}">Удалить</button></td></tr>`,
      )
      .join("");
    $("entries").innerHTML =
      rows || '<tr><td colspan="4">Здесь нет файлов</td></tr>';
    $("entries")
      .querySelectorAll(
        "a[data-open],button[data-edit],button[data-download],button[data-rename],button[data-delete]",
      )
      .forEach((x) =>
        x.addEventListener("click", async (e) => {
          e.preventDefault();
          let type = ["open", "edit", "download", "rename", "delete"].find(
            (k) => x.dataset[k] !== undefined,
          );
          let f = j.entries[+x.dataset[type]];
          let path = join(cwd, f.name);
          if (type === "open") {
            if (f.directory) {
              cwd = path;
              refresh();
            } else edit(path);
          }
          if (type === "edit") edit(path);
          if (type === "download")
            location.href = "/api/download?path=" + encodeURIComponent(path);
          if (type === "rename") rename(path, f.name);
          if (type === "delete") del(path, f.directory);
        }),
      );
    msg("");
  } catch (e) {
    msg("Ошибка списка: " + e.message, true);
  }
}
function up() {
  if (cwd !== "/") {
    cwd = cwd.substring(0, cwd.lastIndexOf("/")) || "/";
    refresh();
  }
}
async function post(endpoint, args) {
  try {
    let r = await fetchApi(endpoint + "?" + new URLSearchParams(args), {
      method: "POST",
    });
    msg(await r.text());
    await refresh();
  } catch (e) {
    msg("Ошибка: " + e.message, true);
  }
}
async function mkdir() {
  let name = $("newfolder").value.trim();
  if (!validName(name)) return msg("Введите имя папки без / и \\", true);
  await post("/api/mkdir", { path: join(cwd, name) });
  $("newfolder").value = "";
}
async function rename(path, name) {
  let n = prompt("Новое имя файла/папки", name);
  if (n === null) return;
  n = n.trim();
  if (!validName(n)) return msg("Неправильное имя", true);
  await post("/api/rename", { from: path, to: join(cwd, n) });
}
async function del(path, isdir) {
  if (
    !confirm(
      "Удалить " + path + "?" + (isdir ? " Папка должна быть пустой." : ""),
    )
  )
    return;
  await post("/api/delete", { path });
}
async function edit(path) {
  try {
    let r = await fetchApi("/api/read?path=" + encodeURIComponent(path));
    $("edittext").value = await r.text();
    active = path;
    $("editname").textContent = path;
    $("editor").style.display = "block";
    $("editor").scrollIntoView();
  } catch (e) {
    msg("Нельзя открыть в текстовом редакторе: " + e.message, true);
  }
}
function closeEditor() {
  $("editor").style.display = "none";
  active = "";
}
async function saveText() {
  if (!active) return;
  try {
    let r = await fetchApi("/api/save", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
      },
      body: new URLSearchParams({ path: active, content: $("edittext").value }),
    });
    msg(await r.text());
    closeEditor();
    await refresh();
  } catch (e) {
    msg("Ошибка сохранения: " + e.message, true);
  }
}
async function upload() {
  const fs = [...$("files").files];
  if (!fs.length) return msg("Выберите файлы", true);
  for (const f of fs) {
    let form = new FormData();
    form.append("file", f, f.name);
    try {
      await fetchApi("/api/upload?dir=" + encodeURIComponent(cwd), {
        method: "POST",
        body: form,
      });
      msg("Загружен: " + f.name);
    } catch (e) {
      msg("Ошибка загрузки " + f.name + ": " + e.message, true);
      break;
    }
  }
  $("files").value = "";
  await refresh();
}
const drop = $("drop");
drop.addEventListener("dragover", (e) => {
  e.preventDefault();
  drop.classList.add("drag");
});
drop.addEventListener("dragleave", () => drop.classList.remove("drag"));
drop.addEventListener("drop", (e) => {
  e.preventDefault();
  drop.classList.remove("drag");
  if (e.dataTransfer.files.length) {
    $("files").files = e.dataTransfer.files;
    upload();
  }
});
function validPath(path) {
  return (
    typeof path === "string" &&
    path.startsWith("/") &&
    !path.includes("..") &&
    !/[\\:#?]/.test(path) &&
    !path.includes("//") &&
    path.length <= 128
  );
}
(async () => {
  const query = new URLSearchParams(location.search);
  const requestedFile = query.get("edit"),
    requestedDir = query.get("dir");
  if (requestedFile && validPath(requestedFile)) {
    cwd = requestedFile.substring(0, requestedFile.lastIndexOf("/")) || "/";
    await refresh();
    await edit(requestedFile);
  } else {
    cwd =
      requestedDir && validPath(requestedDir)
        ? requestedDir.replace(/\/$/, "") || "/"
        : "/";
    await refresh();
  }
})();

// Привязка элементов здесь позволяет не размещать обработчики JavaScript в HTML.
$("button-up").addEventListener("click", up);
$("button-refresh").addEventListener("click", refresh);
$("button-upload").addEventListener("click", upload);
$("button-mkdir").addEventListener("click", mkdir);
$("button-saveText").addEventListener("click", saveText);
$("button-closeEditor").addEventListener("click", closeEditor);
</script>
  <script>
(()=>{
 const $=id=>document.getElementById(id);
 async function check(){
  try{const r=await fetch('/setup/status',{cache:'no-store'});if(!r.ok)throw Error(await r.text());const d=await r.json();
   $('bootstrapState').textContent=!d.fsMounted?'LittleFS не смонтирована: проверьте таблицу разделов и память. Существующие данные не стирались.':d.webReady?'Все необходимые веб-файлы загружены. Можно перейти на главную.':'Ещё нужны файлы: '+d.missing.join(', ');
   const u=new URL(location.href);u.port='';u.pathname='/';u.search='';u.hash='';$('bootstrapMain').href=u.href;$('bootstrapMain').hidden=!d.webReady;
  }catch(e){$('bootstrapState').textContent=String(e.message||e)+' Проверьте связь с контроллером и повторите проверку.';}
 }
 $('bootstrapCheck').onclick=check;
 $('button-upload').addEventListener('click',()=>setTimeout(check,1500));
 check();
})();
</script></body>
</html>
)BOOTPAGE";
